using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ash_Affordability_Checker.Application.Constants
{
  public record AffordabilityConstants
  {
    public const decimal MONTHLY_RENT_MULTIPLIER = 1.25m;
  }
}
