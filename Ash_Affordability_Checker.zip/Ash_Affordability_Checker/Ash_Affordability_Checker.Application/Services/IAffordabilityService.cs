using Ash_Affordability_Checker.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ash_Affordability_Checker.Application.Services
{
  public interface IAffordabilityService
  {
    Task<List<Property>> Check(List<Transaction> transactions, List<Property> selectedProperties);
  }
}
