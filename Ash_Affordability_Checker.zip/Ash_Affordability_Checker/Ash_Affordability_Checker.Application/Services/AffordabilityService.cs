using Ash_Affordability_Checker.Application.Constants;
using Ash_Affordability_Checker.Application.Helpers;
using Ash_Affordability_Checker.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ash_Affordability_Checker.Application.Services
{
  public class AffordabilityService : IAffordabilityService
  {
    public async Task<List<Property>> Check(List<Transaction> transactions, List<Property> selectedProperties)
    {
      List<Property> affordableProperties = new List<Property>();
      var disposableIncome = IncomeHelper.CalculateDisposableIncome(transactions);

      await Parallel.ForEachAsync(selectedProperties, async (property, token) =>
      {
        if (AffordabilityHelper.CanAffordProperty(disposableIncome, property.MonthlyRent))
        {
          affordableProperties.Add(property);
        }
      });

      return affordableProperties;
    }
  }
}
