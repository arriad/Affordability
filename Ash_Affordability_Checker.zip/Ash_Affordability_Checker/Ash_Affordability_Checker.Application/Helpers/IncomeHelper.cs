using Ash_Affordability_Checker.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ash_Affordability_Checker.Application.Helpers
{
  public class IncomeHelper
  {
    public static decimal? CalculateDisposableIncome(List<Transaction> transactions)
    {
      var totalExpense = transactions.Sum(b=>b.MoneyOut);

      var totalIncome = transactions.Sum(b=>b.MoneyIn);

      return totalIncome - totalExpense;
    }
  }
}
