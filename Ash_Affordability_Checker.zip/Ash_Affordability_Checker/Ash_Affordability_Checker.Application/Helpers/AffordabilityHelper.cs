using Ash_Affordability_Checker.Application.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ash_Affordability_Checker.Application.Helpers
{
  public class AffordabilityHelper
  {
    public static bool CanAffordProperty(decimal? income, decimal monthlyRent)
    {
      var adjustedMonthlyRent = monthlyRent * AffordabilityConstants.MONTHLY_RENT_MULTIPLIER;
      return income > adjustedMonthlyRent;
    }
  }
}
