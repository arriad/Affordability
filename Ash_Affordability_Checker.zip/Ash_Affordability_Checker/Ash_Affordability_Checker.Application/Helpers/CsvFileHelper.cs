using Ash_Affordability_Checker.Domain.Entities;

namespace Ash_Affordability_Checker.Application.Helpers
{
  public class CsvFileHelper
  {
    private const int moneyOutIndex = 3;
    private const int moneyInIndex = 4;
    private const int balanceMoneyIndex = 5;
    public static async Task<List<Transaction>> ReadTransactionFile(string filePath, int skippedLines)
    {
      List<Transaction> transactions = new List<Transaction>();
      var transactionLines = await ReadFile(filePath, skippedLines);
      foreach (var originalLine in transactionLines)
      {
        Transaction transaction = new Transaction();
        var transactionLine = ReplaceCommas(originalLine,"\"£","\"","");
        transactionLine = ReplaceCommas(transactionLine,"\"", "\"", "|");
        var values = transactionLine.Split(',');        

        transaction.TransactionDate = values[0];
        transaction.PaymentType = values[1].Trim();
        transaction.Description = values[2].Replace('|',',').Trim();
        if (decimal.TryParse(values[3].Replace("£",""), out decimal moneyOut))
        {
          transaction.MoneyOut = moneyOut;
        }
        if (decimal.TryParse(values[4].Replace("£", ""), out decimal moneyIn))
        {
          transaction.MoneyIn = moneyIn;
        }
        if (decimal.TryParse(values[5].Replace("£", ""), out decimal balance))
        {
          transaction.Balance = balance;
        }

        transactions.Add(transaction);
      }
      return transactions;
    }

    public static async Task<List<Property>> ReadPropertiesFile(string filePath, int skippedLines)
    {
      List<Property> properties = new List<Property>();
      var propertyLines = await ReadFile(filePath, skippedLines);
      foreach (var originalLine in propertyLines)
      {
        Property property = new Property();
        var propertyLine = ReplaceCommas(originalLine, "\"", "\"", "|");
        var values = propertyLine.Split(',');

        if (int.TryParse(values[0], out int id))
        {
          property.Id = id;
        }
         property.Address = values[1].Replace('|',',').Trim();
        if (decimal.TryParse(values[2], out decimal price))
        {
          property.MonthlyRent = price;
        }
        properties.Add(property);
      }
      return properties;
    }
    private static string ReplaceCommas(string transactionLine, string startingPattern, string endingPattern, string replacement)
    {
      while (transactionLine.Contains(startingPattern))
      {
        transactionLine = ReplaceComma(transactionLine,startingPattern, endingPattern, replacement);
      }

      return transactionLine;
    }

      private static string ReplaceComma(string transactionLine, string startingPattern, string endingPattern, string replacement)
    {
      var indexOfStartingQuote = transactionLine.IndexOf(startingPattern);
      var indexOfEndingQuote = transactionLine.IndexOf(endingPattern, indexOfStartingQuote+1);
      var originalString = transactionLine.Substring(indexOfStartingQuote, (indexOfEndingQuote-indexOfStartingQuote)+1);
      return transactionLine.Replace(originalString, originalString.Replace("\"","").Replace(",", replacement));
    }

   
    private static async Task<string[]> ReadFile(string filePath, int skippedLines)
    {
      var lines = await File.ReadAllLinesAsync(filePath);
      return lines.Skip(skippedLines).ToArray();
    }
  }
}
