using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ash_Affordability_Checker.Domain.Entities
{
  public record Transaction
  {
    public string TransactionDate { get; set; }
    public string PaymentType { get; set; }
    public string? Description { get; set; }
    public decimal? MoneyIn { get; set; }
    public decimal? MoneyOut { get; set; }
    public decimal? Balance { get; set; }
  }
}
