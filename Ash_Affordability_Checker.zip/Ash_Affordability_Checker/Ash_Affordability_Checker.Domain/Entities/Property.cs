namespace Ash_Affordability_Checker.Domain.Entities
{
  public record Property
  {
    public int Id { get; set; }
    public string? Address { get; set; }
    public decimal MonthlyRent { get; set; }
  }
}
