using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ash_Affordability_Checker.Domain.Entities
{
  public record Statement
  {
    public DateTime StatementDate { get; set; }
    public decimal StartingBalance { get; set; }
    public decimal EndingBalance { get; set; }  
    public List<Transaction> Transactions { get; set; }
  }
}
