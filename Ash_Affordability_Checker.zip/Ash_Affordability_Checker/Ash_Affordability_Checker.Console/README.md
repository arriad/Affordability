# Vouch Backend Exercise
 
One of the most frustrating things about the lettings process for tenants is 
the affordability checks. 

Usually this is done after the tenant has viewed multiple properties, 
selected one and paid a security deposit. If the tenant fails the affordability
check they will not be allowed into the property and will need to restart their
search. In some cases they may lose the security deposit. 

In order to ease this frustration we want you to build a service that allows 
tenants to carry out an affordability check against a list of properties. 

A tenant is able to afford a property if their monthly recurring income exceeds
their monthly recurring expenses by the total of the monthly rent times 125%. 

Note: Creating a text file/README of you assumptions and thoughts helps us 
understand your reasoning when marking the test.

1/ Given the pseudo code below, write a unit test and corresponding 
models/functionality that will read a list of properties and a list of bank 
transactions and calculate which properties the tenant can afford.

```
//Given 

//Transactions - date, type description, money out, money in, balance
"1st January 2020", "Direct Debit", "Gas & Electricity", "£95.06", "", "£1200.04"
"2nd January 2020", "ATM", "HSBC Holborn", "£20.00", "", "£1180.04"
"3rd January 2020", "Standing Order", "London Room", "£500.00", "", "£680.04"
"4th January 2020", "Bank Credit", "Awesome Job Ltd", "", "£1254.23", "£1934.27"
"1st February 2020", "Direct Debit", "Gas & Electricity", "£95.06", "", "£1839.21"
"2nd February 2020", "ATM", "@Random", "£50.00", "", "£1789.21"
"3rd February 2020", "Standing Order", "London Room", "£500.00", "", "£1289.21"
"4th February 2020", "Bank Credit", "Awesome Job Ltd", "", "£1254.23", "£2543.44"

// Properties - id, address, rent per month
1, "1, Oxford Street", 300
2, "12, St John Avenue", 750
3, "Flat 43, Expensive Block", 1200
4, "Flat 44, Expensive Block", 1150

            
// When

affordableProperties = affordabilityService.Check(transactions, properties);
        
// Then

Assert.AreEqual(1, affordableProperties.Count)
Assert.AreEqual("1, Oxford Street", affordableProperties[0].address)
        
```

*** Unit test created and ran successfully ***

2/ Build a program that uses the files `bank_statement.csv` and `properties.csv` 
provided in `/files` and runs the through the service to calculate 
the correct result. 

*** A program has been created and github repo shared ***

3/ What other tests should be written to ensure our functionality is 
working as intended and handles errors gracefully? Implement said tests.

*** Following additional tests should be written ***

a. Test all public methods in all classes
b. Test for failures, use invalid files, files with invalid delimeters
 and invalid character
c. Text for edge cases, where user cannot afford any properties or can afford all
 properties.


# Assumptions (by Candidate)

a. We are not taking average monthly balance, but rather taking the balance
 for the whole period that the transactions span across. 
 
 b. Only currency symbol to be used is British Pound
  
  c. We are using any Money coming into account as income not just salary
