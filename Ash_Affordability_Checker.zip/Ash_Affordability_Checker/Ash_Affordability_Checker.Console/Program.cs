// See https://aka.ms/new-console-template for more information
using Ash_Affordability_Checker.Application.Helpers;
using Ash_Affordability_Checker.Application.Services;
using Ash_Affordability_Checker.Domain.Entities;


var transactions =  await CsvFileHelper.ReadTransactionFile("./files/bank_statement.csv",11);
var properties = await CsvFileHelper.ReadPropertiesFile("./files/properties.csv", 1);

IAffordabilityService affordabilityService = new AffordabilityService();
var affordableProperties = await affordabilityService.Check(transactions, properties);

Console.WriteLine($"You can afford {affordableProperties?.Count} properties");
if (affordableProperties?.Count > 0)
{
  Console.WriteLine("Here are the properties:");
  foreach (Property property in affordableProperties)
  {

    Console.WriteLine($"Property Address: {property.Address}");
  }
}
Console.WriteLine("Press enter to exit");
Console.ReadLine();
