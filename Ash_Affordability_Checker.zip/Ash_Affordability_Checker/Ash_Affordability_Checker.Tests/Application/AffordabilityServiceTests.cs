using Ash_Affordability_Checker.Application.Helpers;
using Ash_Affordability_Checker.Application.Services;
using Xunit;

namespace Ash_Affordability_Checker.Tests.Application
{
  public class AffordabilityServiceTests
  {
    private readonly IAffordabilityService target;

    public AffordabilityServiceTests()
    {
      target = new AffordabilityService();
    }

    [Fact]
    public async Task Should_Return_Affordable_Properties()
    {
      var transactions = await CsvFileHelper.ReadTransactionFile("./TestData/transactions.csv", 1);
      var properties = await CsvFileHelper.ReadPropertiesFile("./TestData/properties.csv", 1);

      // When

      var affordableProperties = await target.Check(transactions, properties);

      // Then

      Assert.Equal(2, affordableProperties.Count);
      Assert.Equal("1, Oxford Street", affordableProperties[0].Address);
    }
  }
}
